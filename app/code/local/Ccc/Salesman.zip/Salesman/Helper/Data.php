<?php

class Ccc_Salesman_Helper_Data extends Mage_Core_Helper_Abstract
{
    public function __construct()
    {
    }
}
