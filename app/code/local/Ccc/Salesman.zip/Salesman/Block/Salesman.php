<?php

class Ccc_Salesman_Block_Product extends Mage_Core_Block_Template
{
    function __construct()
    {
        parent::__construct();
    }

}